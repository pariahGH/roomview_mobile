package tech.teksavvy.roomviewmobile

import android.content.Context
import androidx.room.*
import com.univocity.parsers.annotations.Parsed
import java.nio.charset.Charset
import java.io.Serializable
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Entity(tableName = "rooms")
class RoomItem() : Serializable{
    @ColumnInfo(name = "ip")
    @Parsed
    val ip:String = ""
    @PrimaryKey
    @ColumnInfo(name = "room_number")
    @Parsed
    val room:String = ""
    val teststring = "need help".toByteArray(Charset.forName("US-ASCII"))
            .joinToString(separator="") { i -> String.format("%02x",i) }
    //I don't know what this means but the systems require this be sent to them for them to start talking to us
    val data = intArrayOf(0x01,0x00,0x0b,0x0a,0xa6,0xca,0x37,0x00,0x72,0x40,0x00,0x00,0xf1,0x01)
}

@Database(entities = arrayOf(RoomItem::class), version = 1)
abstract class RoomDb : RoomDatabase() {

    abstract fun roomDao(): RoomDao

    companion object {

        @Volatile private var INSTANCE: RoomDatabase? = null

        fun getInstance(context: Context): RoomDatabase =
                INSTANCE ?: synchronized(this) {
                    INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
                }

        private fun buildDatabase(context: Context) =
                Room.databaseBuilder(context.applicationContext,
                        RoomDatabase::class.java, "Sample.db")
                        .build()
    }
}

@Dao
interface RoomDao {

    @Query("SELECT * FROM Rooms WHERE room_number = :id")
    fun getRoonmById(id: String): List<RoomItem>
    @Query("SELECT * FROM Rooms")
    fun getRooms(): List<RoomItem>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRoom(room: RoomItem)
    @Query("DELETE FROM Rooms")
    fun deleteAllRooms()
}
